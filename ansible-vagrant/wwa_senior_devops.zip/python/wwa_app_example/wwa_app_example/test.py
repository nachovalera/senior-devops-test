import requests

def some_function():
    pass
